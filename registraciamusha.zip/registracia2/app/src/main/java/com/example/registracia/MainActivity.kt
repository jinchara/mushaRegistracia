package com.example.registracia

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    private lateinit var saxeli1 : EditText
    private lateinit var paroli1 : EditText
    private lateinit var gvari1 : EditText
    private lateinit var email1 : EditText
    val gmaili = "@gmail.com"




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }


    fun shesvla1(view: View){



        saxeli1 = findViewById(R.id.saxeli)
        gvari1 = findViewById(R.id.gvari)
        paroli1 = findViewById(R.id.password)
        email1 = findViewById(R.id.email)

        val shemowmeba = email1.text.toString().contains(gmaili)

        if (shemowmeba == false){
            Toast.makeText(this , "araswori emailia " , Toast.LENGTH_SHORT).show()
        }else {
            shemowmeba == true


        }
        if (saxeli1.length() < 3 || saxeli1.length() == 0 ){
            Toast.makeText(this,"არასწორი სახელი!",Toast.LENGTH_SHORT).show()
        }
        if (gvari1.length() < 4 || gvari1.length() == 0){
            Toast.makeText(this,"არასწორი გვარი!",Toast.LENGTH_SHORT).show()
        }

        if (paroli1.length() < 8 || paroli1.length() == 0){
            Toast.makeText(this,"არასწორი პაროლი!",Toast.LENGTH_SHORT).show()
        }
        if (email1.length() < 10 || email1.length() == 0){
            email1.setError("enter valid email")
            Toast.makeText(this,"არასწორი E-mail!",Toast.LENGTH_SHORT).show()
        }
        if (shemowmeba == true && saxeli1.length()>3 && gvari1.length() > 4 && paroli1.length() >8 && email1.length()>10 ){
            Toast.makeText(this , "გილოცავ , შენ წარმატებით დარეგისტრირდი!" , Toast.LENGTH_LONG).show()
        }
        val intent = Intent(this , MainActivity::class.java)
        startActivity(intent)




    }




}